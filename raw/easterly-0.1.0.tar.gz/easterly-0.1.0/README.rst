===============================
easterly
===============================

.. image:: https://badge.fury.io/py/easterly.png
    :target: http://badge.fury.io/py/easterly
    
.. image:: https://travis-ci.org/oruu/easterly.png?branch=master
        :target: https://travis-ci.org/oruu/easterly

.. image:: https://pypip.in/d/easterly/badge.png
        :target: https://crate.io/packages/easterly?version=latest


Easterly

* Free software: BSD license
* Documentation: http://easterly.rtfd.org.

Features
--------

* TODO