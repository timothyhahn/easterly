.. :changelog:

History
-------

0.1.0 (2013-08-11)
++++++++++++++++++

* First release on PyPI.